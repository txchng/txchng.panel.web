<template src="./requestStatusIcon.html"></template>
<script src="./requestStatusIcon.ctrl.js"></script>
<style scoped src="./requestStatusIcon.css"></style>
