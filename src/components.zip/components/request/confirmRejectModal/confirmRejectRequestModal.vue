<template src="./confirmRejectRequestModal.html"></template>
<script src="./confirmRejectRequestModal.ctrl.js"></script>
<style scoped src="./confirmRejectRequestModal.css"></style>
