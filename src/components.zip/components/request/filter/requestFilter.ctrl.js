export default {
  name: 'RequestFilter',
  props:{
    onFilterObjectChanged: { type: Function },
  },
  components:{},
  data() {
    return {
      searchKeyword: undefined,
      statusList:[
        {
          systemValue:'all',
          ar_title: 'همه',
          fa_title: 'همه',
          en_title: 'all',
        },
        {
          systemValue:'new',
          ar_title: 'جدید',
          fa_title: 'جدید',
          en_title: 'new',
        },
        {
          systemValue:'read',
          ar_title: 'دیده شده',
          fa_title: 'دیده شده',
          en_title: 'read',
        },
        {
          systemValue:'rejected',
          ar_title: 'رد شده',
          fa_title: 'رد شده',
          en_title: 'rejected',
        },
        {
          systemValue:'waged',
          ar_title: 'در جریان',
          fa_title: 'در جریان',
          en_title: 'waged',
        },
        {
          systemValue:'canceled',
          ar_title: 'لغو شده',
          fa_title: 'لغو شده',
          en_title: 'canceled',
        },
        {
          systemValue:'accepted',
          ar_title: 'توافق شده',
          fa_title: 'توافق شده',
          en_title: 'accepted',
        },
      ],
      selectedStatus:undefined,

    }
  },
  methods: {
    seachKeywordChanged(){
      if(this.searchKeyword.trim().toString() == ''){
        this.searchKeyword = undefined;
      }
      this.callParent();
    },
    selectStatus(event){
      var status = event.target.value;
      this.selectedStatus = status;
      if(status == 'all'){
        this.selectedStatus  = undefined
      }
      this.callParent();
    },
    callParent(){
      if(this.onFilterObjectChanged){
          this.onFilterObjectChanged(this.selectedStatus, this.searchKeyword);
      }
    }

  },
}
