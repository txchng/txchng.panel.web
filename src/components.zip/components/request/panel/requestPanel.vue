<template src="./requestPanel.html"></template>
<script src="./requestPanel.ctrl.js"></script>
<style scoped src="./requestPanel.css"></style>
