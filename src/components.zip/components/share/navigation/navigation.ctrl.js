import TrackingCodeSearchBox from '@/components/trackingCode/seachBox/trackingCodeSeachBox.vue'
export default {
  name: 'NavigationPanel',
  components:{TrackingCodeSearchBox},
  props:[],
};
