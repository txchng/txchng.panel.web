<template src="./currencyLabel.html"></template>
<script src="./currencyLabel.ctrl.js"></script>
<style scoped src="./currencyLabel.css"></style>
