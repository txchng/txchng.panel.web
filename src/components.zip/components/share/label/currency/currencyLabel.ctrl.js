export default {
  name: 'CurrencyLabel',
  props:["currency"],
}
