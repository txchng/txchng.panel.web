<template src="./dateTimeLable.html"></template>
<script src="./dateTimeLable.ctrl.js"></script>
<style scoped src="./dateTimeLable.css"></style>
