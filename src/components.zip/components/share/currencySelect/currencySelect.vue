<template src="./currencySelect.html"></template>
<script src="./currencySelect.ctrl.js"></script>
<style scoped src="./currencySelect.css"></style>
