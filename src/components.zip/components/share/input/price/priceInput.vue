<template src="./priceInput.html"></template>
<script src="./priceInput.ctrl.js"></script>
<style scoped src="./priceInput.css"></style>
