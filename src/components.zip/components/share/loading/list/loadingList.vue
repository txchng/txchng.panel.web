<template src="./loadingList.html"></template>
<script src="./loadingList.ctrl.js"></script>
<style scoped src="./loadingList.css"></style>
