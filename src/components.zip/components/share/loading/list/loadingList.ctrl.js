export default {
  name: 'LoadingList',
  props:[],
};
