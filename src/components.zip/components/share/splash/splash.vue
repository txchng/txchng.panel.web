<template src="./splash.html"></template>
<script src="./splash.ctrl.js"></script>
<style scoped src="./splash.css"></style>
