<template src="./provinceSelect.html"></template>
<script src="./provinceSelect.ctrl.js"></script>
<style scoped src="./provinceSelect.css"></style>
