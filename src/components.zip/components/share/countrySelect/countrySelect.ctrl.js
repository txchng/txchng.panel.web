
export default {
  name: 'CountrySelect',
  data() {
    return {
      countryList: [
        {
          _id: '1',
          name:'iraq'
        },
        {
          _id: '2',
          name:'iran'
        }
      ],
    }
  }
}
