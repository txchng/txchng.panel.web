<template src="./coWorkerSelect.html"></template>
<script src="./coWorkerSelect.ctrl.js"></script>
<style scoped src="./coWorkerSelect.css"></style>
