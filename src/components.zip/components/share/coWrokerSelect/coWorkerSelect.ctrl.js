import axios from 'axios';

export default {
  name: 'CoWorkerSelect',
  props: {
    onCoWorkerSelectedMethod: { type: Function }
  },
  data() {
    return {
      selectedCompany: {},
      companyList: [],
    }
  },
  methods:{
    onCoWorkerSelected(event) {
      this.onCoWorkerSelectedMethod(event.target.value);
    },
    getCompanyCoWorkerList() {
      var params = {
        token: 'fackedAuthToken',
      };
      axios.post('http://116.203.75.73:8002/company/get_coworkers_company', params)
      .then(response => this.companyList = response.data.companyList)
      .catch(err => console.log(err))
    }
  },
  created() {
    this.getCompanyCoWorkerList();
 }
}
