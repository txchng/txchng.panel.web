<template src="./citySelect.html"></template>
<script src="./citySelect.ctrl.js"></script>
<style scoped src="./citySelect.css"></style>
