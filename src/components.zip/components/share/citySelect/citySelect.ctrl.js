
export default {
  name: 'ProvinceSelect',
  data() {
    return {
      provinceList: [
        {
          _id: '1',
          name:'Tehran'
        },
        {
          _id: '2',
          name:'Baqdad'
        }
      ],
    }
  }
}
