<template src="./currencyPanel.html"></template>
<script src="./currencyPanel.ctrl.js"></script>
<style scoped src="./currencyPanel.css"></style>
