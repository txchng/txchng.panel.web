import axios from 'axios';
import TransactionList from '@/components/transaction/list/transactionList.vue';
import LoadingList from '@/components/share/loading/list/loadingList.vue';

export default {
  name: 'TransactionPanel',
  components:{
    TransactionList,
    LoadingList
  },
  title: 'سامانه تبادل مشتری | تراکنش ها',

  data() {
    return {
      transactionList: [],
      token: undefined,
      isLoading: false,
    }
  },
  methods: {
    backToList() {
      this.$router.push({path: '/company'})
    },
    getTransactionList() {
      this.isLoading = true;
      var params = {
        token: this.token,
      };
      axios.post('http://116.203.75.73:8002/transaction/getAll_company', params)
      .then(this.onGetTransactionListSuccsess)
      .catch(this.onGetTransactionListFail);
    },
    onGetTransactionListSuccsess(response){
      this.isLoading = false;
      this.transactionList = response.data.transactionList;
    },
    onGetTransactionListFail(err){
      this.isLoading = false;
      console.log(err);
    }
  },
  created() {
    this.token = localStorage.token;
    if(!this.token){
      this.$router.push({path: '/login'})
    }
    this.getTransactionList();
 }
}
