import CurrencyLabel from '@/components/share/label/currency/currencyLabel.vue'
import DateTimeLabel from '@/components/share/label/dateTime/dateTimeLable.vue'

export default {
    name: 'TransactionListItem',
    props: ["transaction", "index"],
    components: {CurrencyLabel, DateTimeLabel},
    computed: {
        bgColor: function () {
            return this.index % 2 === 0 ? '' : 'bg-light-blue';
        }
    },
    methods: {
        backToList() {
            this.$router.push({path: '/company'})
        },
        showRemittanceDetail() {
            this.$router.push({path: '/remittance/detail/' + this.transaction.remittance._id})
        }
    },
}
