<template src="./trackingCodeSeachBox.html"></template>
<script src="./trackingCodeSeachBox.ctrl.js"></script>
<style scoped src="./trackingCodeSeachBox.css"></style>
