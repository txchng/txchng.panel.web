<template src="./userSearchBox.html"></template>
<script src="./userSearchBox.ctrl.js"></script>
<style scoped src="./userSearchBox.css"></style>
