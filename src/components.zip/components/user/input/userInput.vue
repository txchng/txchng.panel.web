<template src="./userInput.html"></template>
<script src="./userInput.ctrl.js"></script>
<style scoped src="./userInput.css"></style>
