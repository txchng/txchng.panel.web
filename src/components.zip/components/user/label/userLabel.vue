<template src="./userLabel.html"></template>
<script src="./userLabel.ctrl.js"></script>
<style scoped src="./userLabel.css"></style>
