<template src="./userPanel.html"></template>
<script src="./userPanel.ctrl.js"></script>
<style scoped src="./userPanel.css"></style>
