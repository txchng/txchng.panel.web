<template src="./coWorkerList.html"></template>
<script src="./coWorkerList.ctrl.js"></script>
<style scoped src="./coWorkerList.css"></style>
