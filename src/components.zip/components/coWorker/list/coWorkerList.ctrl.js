import CoWorkerListItem from '@/components/coWorker/listItem/coWorkerListItem.vue'

export default {
  name: 'CoWorkerList',
  props:{
    coWorkerList: Array,
  },
  components:{ CoWorkerListItem },
  data() {
    return {
    }
  },
  methods: {},
  created() {

 }
}
