<template src="./coWorkerListItem.html"></template>
<script src="./coWorkerListItem.ctrl.js"></script>
<style scoped src="./coWorkerListItem.css"></style>
