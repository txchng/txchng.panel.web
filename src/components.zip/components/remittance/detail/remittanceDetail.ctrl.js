import axios from 'axios';

export default {
  name: 'RemittanceDetail',
  props:["remittanceId"],
  data() {
    return {
      remittance: {},
    }
  },
  methods: {
    backToList() {
      this.$router.push({path: '/company'})
    },
  },
  created() {
    var params = {
      remittanceId: this.remittanceId,
      token: 'fackedAuthToken',
    };
    axios.post('http://116.203.75.73:8002/remittance/get_remittance_intermediateCompany_id', params)
    .then(response => this.remittance = response.data.remittance)
    .catch(err => console.log(err))
 }
}
