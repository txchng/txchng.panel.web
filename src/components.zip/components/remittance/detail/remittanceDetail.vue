<template src="./remittanceDetail.html"></template>
<script src="./remittanceDetail.ctrl.js"></script>
<style scoped src="./remittanceDetail.css"></style>
