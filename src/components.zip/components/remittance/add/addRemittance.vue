<template src="./addRemittance.html"></template>
<script src="./addRemittance.ctrl.js"></script>
<style scoped src="./addRemittance.css"></style>
