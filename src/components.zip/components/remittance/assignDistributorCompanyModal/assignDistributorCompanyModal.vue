<template src="./assignDistributorCompanyModal.html"></template>
<script src="./assignDistributorCompanyModal.ctrl.js"></script>
<style scoped src="./assignDistributorCompanyModal.css"></style>
