<template src="./sendDistributionRequestModal.html"></template>
<script src="./sendDistributionRequestModal.ctrl.js"></script>
<style scoped src="./sendDistributionRequestModal.css"></style>
