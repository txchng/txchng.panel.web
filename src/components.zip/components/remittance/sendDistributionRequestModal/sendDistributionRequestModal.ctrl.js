import axios from 'axios';

export default {
  name: 'SendDistributionRequestModal',
  props:["remittanceId","token"],
  data() {
    return {
      selectedDistributorCompany: {},
      companyList: []
    }
  },
  methods: {
    backToList() {
      this.$router.push({path: '/company'})
    },
    sendDisterbutionRequest() {
      var params = {
        distributorCompany: this.selectedDistributorCompany,
        remittanceId: this.remittanceId,
        token: this.token,
      };
      axios.post('http://116.203.75.73:8002/request/createForRemittance', params)
      .then(response => {
        alert('saved!')
        this.remittance = response.data.remittance
      })
      .catch(err => console.log(err))
    },
  },
  created() {
    var params = {
      token: 'fackedAuthToken',
    };
    axios.post('http://116.203.75.73:8002/company/get_coworkers_company', params)
    .then(response => this.companyList = response.data.companyList)
    .catch(err => console.log(err))
  },
}
