<template src="./remittanceStatusIcon.html"></template>
<script src="./remittanceStatusIcon.ctrl.js"></script>
<style scoped src="./remittanceStatusIcon.css"></style>
