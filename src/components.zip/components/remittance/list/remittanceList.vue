<template src="./remittanceList.html"></template>
<script src="./remittanceList.ctrl.js"></script>
<style scoped src="./remittanceList.css"></style>
