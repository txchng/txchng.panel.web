<template src="./remittanceListItem.html"></template>
<script src="./remittanceListItem.ctrl.js"></script>
<style scoped src="./remittanceListItem.css"></style>
