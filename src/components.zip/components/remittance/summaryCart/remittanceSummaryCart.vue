<template src="./remittanceSummaryCart.html"></template>
<script src="./remittanceSummaryCart.ctrl.js"></script>
<style scoped src="./remittanceSummaryCart.css"></style>
