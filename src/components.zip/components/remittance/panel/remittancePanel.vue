<template src="./remittancePanel.html"></template>
<script src="./remittancePanel.ctrl.js"></script>
<style scoped src="./remittancePanel.css"></style>
