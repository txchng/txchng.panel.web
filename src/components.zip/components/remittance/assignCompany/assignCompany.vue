<template src="./assignCompany.html"></template>
<script src="./assignCompany.ctrl.js"></script>
<style scoped src="./assignCompany.css"></style>
