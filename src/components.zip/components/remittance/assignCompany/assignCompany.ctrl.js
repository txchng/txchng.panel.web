import CompanyRestResource from '@/util/http/company.srv';
import RemittanceRestResource from '@/util/http/remittance.srv';
import RemittanceSummaryCart from '@/components/remittance/summaryCart/remittanceSummaryCart.vue';
import CurrencySelect from '@/components/share/currencySelect/currencySelect.vue'
import WageInput from '@/components/wage/input/wageInput.vue';

const CompanyService = new CompanyRestResource();
const RemittanceService = new RemittanceRestResource();


export default {
    name: 'AssignCompany',
    components: {CurrencySelect, WageInput, RemittanceSummaryCart},
    props: ["remittanceId"],
    title: 'سامانه تبادل مشتری | تعیین شرکت همکار',

    data() {
        return {
            selectedIntermediateCompany: undefined,
            distributorCompanyWage: {price: undefined, currencyId: undefined},
            companyList: [],
            token: undefined,
            company: {},
            remittance: undefined,

        }
    },
    methods: {
        setCurrency(selectedCurrencyId) {
            this.distributorCompanyWage.currencyId = selectedCurrencyId;
        },
        getRemittanceDetail(){
          RemittanceService
              .get(this.token, this.remittanceId)
              .then(this.onGetRemittanceDetailSuccess)
              .catch(this.onGetRemittanceDetailFail);
        },
        onGetRemittanceDetailSuccess(response){
          this.remittance = response.data.remittance;
          this.distributorCompanyWage.currencyId = this.remittance.currency._id;
        },
        onGetRemittanceDetailFail(err){
          console.log(err)
          var MESSAGE_SAVE_FAILE = 'خطا: ' + err.message;
          this.saveToast.text(MESSAGE_SAVE_FAILE).goAway(700);
        },
        setDisterbuterCompany() {
            var MESSAGE_SAVEING = 'در حال ذخیره سازی ...';
            this.saveToast = this.$toasted.show(MESSAGE_SAVEING, {
                type: 'info',
            });
            RemittanceService
                .setDisterbuterCompany(this.token, this.selectedIntermediateCompany, this.distributorCompanyWage, this.remittanceId)
                .then(this.onSetDistributorCompanySuccess)
                .catch(this.onSetDistributionCompanyFail);
        },
        onSetDistributorCompanySuccess(response) {
          console.log(response);
            var MESSAGE_SAVED = 'ذخیره شد!'
            this.saveToast.text(MESSAGE_SAVED).goAway(1700);
            this.backToList();
        },
        onSetDistributionCompanyFail(err) {
            console.log(err)
            var MESSAGE_SAVE_FAILE = 'خطا: ' + err.message;
            this.saveToast.text(MESSAGE_SAVE_FAILE).goAway(700);
        },
        getCoWorkertCompanyList() {
            CompanyService
                .getCoWorkerCompanyList(this.token)
                .then(this.onGetCoWorkertCompanyListSuccess)
                .catch(this.onGetCoWorkertCompanyListFail);
        },
        onGetCoWorkertCompanyListSuccess(response) {
            this.companyList = response.data.companyList;
        },
        onGetCoWorkertCompanyListFail(err) {
            console.log(err);
        },
        setWage(wagePrice) {
          console.log('asdfasdf');
            this.distributorCompanyWage.price = parseInt(wagePrice);
        },
        backToList() {
          this.$router.push({path: '/remittance/list'})
        },
    },
    computed: {
      isValidForm() {
        if(
          this.remittance &&
          this.selectedIntermediateCompany &&
          this.distributorCompanyWage.price
        ){
          return true;
        }
        return false;
      }
    },
    created() {
        this.token = localStorage.token;
        if (!this.token) {
            this.$router.push({path: '/login'})
        }
        this.getCoWorkertCompanyList();
        this.getRemittanceDetail();
    },
}
