<template src="./remittanceFilter.html"></template>
<script src="./remittanceFilter.ctrl.js"></script>
<style scoped src="./remittanceFilter.css"></style>
