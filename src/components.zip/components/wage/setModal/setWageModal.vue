<template src="./setWageModal.html"></template>
<script src="./setWageModal.ctrl.js"></script>
<style scoped src="./setWageModal.css"></style>
