<template src="./wagePanel.html"></template>
<script src="./wagePanel.ctrl.js"></script>
<style scoped src="./wagePanel.css"></style>
