import axios from 'axios';
import AddWageModal from '@/components/wage/addModal/addWageModal.vue'

export default {
  name: 'WagePanel',
  components:{AddWageModal},
  data() {
    return {
      wageList: [],
      token:'fakeToken',
    }
  },
  methods :{
    getAll() {
      var params = {
        token: 'fackedAuthToken',
      };
      axios.post('http://116.203.75.73:8002/wage/getAll', params)
      .then(response => {
        this.wageList = response.data.wageList
      })
      .catch(err => console.log(err))
    },
  },
  created() {
    this.getAll()
  }
}
