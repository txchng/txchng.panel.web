<template src="./addWageModal.html"></template>
<script src="./addWageModal.ctrl.js"></script>
<style scoped src="./addWageModal.css"></style>
