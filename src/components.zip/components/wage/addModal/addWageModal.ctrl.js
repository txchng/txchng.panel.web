import axios from 'axios';
import CurrencySelect from '@/components/share/currencySelect/currencySelect.vue';
import CoWorkerSelect from '@/components/share/coWrokerSelect/coWorkerSelect.vue';

export default {
  name: 'AddWageModal',
  props: ["token"],
  components: { CurrencySelect, CoWorkerSelect },
  data() {
    return {
      wageList: [],
      wage: { coWorkerCompanyId: '', currencyId: '', minPrice: 0, maxPrice: 0, price: 0 },
    }
  },
  methods :{
    setCurrency(selectedCurrency){
      this.wage.currencyId = selectedCurrency;
    },
    setCoWorkerCompany(selectedCoWorkerCompany){
      console.log(selectedCoWorkerCompany);
      this.wage.coWorkerCompanyId = selectedCoWorkerCompany;
    },
    save() {
      var params = {
        token: 'fackedAuthToken',
        wage: this.wage,
      };
      axios.post('http://116.203.75.73:8002/wage/add', params)
      .then(response => {
        this.wageList = response.data.wageList
      })
      .catch(err => console.log(err))
    },
  },
  created() {
  }
}
