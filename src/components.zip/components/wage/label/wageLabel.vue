<template src="./wageLabel.html"></template>
<script src="./wageLabel.ctrl.js"></script>
<style scoped src="./wageLabel.css"></style>
