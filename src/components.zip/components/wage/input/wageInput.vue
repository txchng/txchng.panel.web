<template src="./wageInput.html"></template>
<script src="./wageInput.ctrl.js"></script>
<style scoped src="./wageInput.css"></style>
