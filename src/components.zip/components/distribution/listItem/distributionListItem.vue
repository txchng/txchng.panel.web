<template src="./distributionListItem.html"></template>
<script src="./distributionListItem.ctrl.js"></script>
<style scoped src="./distributionListItem.css"></style>
