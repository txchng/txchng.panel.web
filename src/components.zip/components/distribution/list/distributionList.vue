<template src="./distributionList.html"></template>
<script src="./distributionList.ctrl.js"></script>
<style scoped src="./distributionList.css"></style>
