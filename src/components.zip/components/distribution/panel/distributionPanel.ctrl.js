import RemittanceRestResource from '@/util/http/remittance.srv';

const RemittanceService = new RemittanceRestResource();

import DistributionList from '@/components/distribution/list/distributionList.vue';
import ConfirmReverseDistributionModal from '@/components/distribution/confirmReverseModal/confirmReverseDistributionModal.vue';
import SubmitDisterbutionDeliveryModal from '@/components/distribution/submitDelivery/submitDisterbutionDeliveryModal.vue';
import LoadingList from '@/components/share/loading/list/loadingList.vue'
import DistributionFilter from '@/components/distribution/filter/distributionFilter.vue'


export default {
  name: 'DistributionPanel',
  components:{ DistributionList , ConfirmReverseDistributionModal, SubmitDisterbutionDeliveryModal, LoadingList, DistributionFilter },
  props:["remittanceId"],
  title: 'سامانه تبادل مشتری | درخواست های توافق شده',

  data() {
    return {
      isLoading: false,
      remittanceList: [],
      visibleRemittanceList: [],
      selectedReveresRemittance: undefined,
      showReverseRemittanceConfirmModal:false,
      selectedDeliveredRemittance: undefined,
      showSubmitDeliveredRemittanceModal: false,
      filterObject:{
        status : undefined,
        searchKeyword : undefined,
      }
    }
  },
  methods: {
    filteChanged(status, searchKeyword){
      console.log('selectedStatus');
      console.log(status);
      console.log('seachKeyword');
      console.log(searchKeyword);
      this.filterObject.status = status;
      this.filterObject.searchKeyword = searchKeyword;
      this.visibleRemittanceList = this.filterRequestList(this.remittanceList, this.filterObject);
      console.log('asdf');
    },
    showSubmitDeliveryDistributionModal(remittance) {
      this.selectedDeliveredRemittance = remittance;
      this.showSubmitDeliveredRemittanceModal = true;
    },

    hideSubmitDeliveryDistributionModal() {
      this.selectedDeliveredRemittance = undefined;
      this.showSubmitDeliveredRemittanceModal = false;
    },

    showReverseDistributionConfrimModal(remittance) {
      this.selectedReveresRemittance = remittance;
      this.showReverseRemittanceConfirmModal = true;
    },

    hideReverseDistributionConfrimModal() {
      this.selectedReveresRemittance = undefined;
      this.showReverseRemittanceConfirmModal = false;
    },

    reverseDistribution(){
      var MESSAGE_SAVEING = 'در حال ذخیره سازی ...';
      this.reverseToast = this.$toasted.show(MESSAGE_SAVEING, {
          type: 'info',
      });
      RemittanceService
      .reverseDistribution(this.token, this.selectedReveresRemittance._id)
      .then(this.onReverseDistributionSuccess)
      .catch(this.onReverseDistributionFail);
    },
    onReverseDistributionSuccess(response){
      var MESSAGE_SAVED = 'ذخیره شد!'
      this.reverseToast.text(MESSAGE_SAVED).goAway(1700);
      console.log(response.data.remittance);
      //this.request = response.data.request
      this.hideReverseDistributionConfrimModal();
      this.getAllDistributionList();
    },
    onReverseDistributionFail(err){
      console.log(err)
      var MESSAGE_SAVE_FAILE = 'خطا: ' + err.message;
      this.reverseToast.text(MESSAGE_SAVE_FAILE).goAway(700);
    },

    deliveredDistribution(){
      var MESSAGE_SAVEING = 'در حال ذخیره سازی ...';
      this.deliveryToast = this.$toasted.show(MESSAGE_SAVEING, {
          type: 'info',
      });
      RemittanceService
      .deliveredDistribution(this.token, this.selectedDeliveredRemittance._id)
      .then(this.onDeliveredDistributionSuccess)
      .catch(this.onDeliveredDistributionFail);
    },
    onDeliveredDistributionSuccess(response){
      var MESSAGE_SAVED = 'ذخیره شد!'
      this.deliveryToast.text(MESSAGE_SAVED).goAway(1700);
      console.log(response.data.remittance);
      //this.request = response.data.request
      this.hideSubmitDeliveryDistributionModal();
      this.getAllDistributionList();
    },
    onDeliveredDistributionFail(err){
      console.log(err)
      var MESSAGE_SAVE_FAILE = 'خطا: ' + err.message;
      this.deliveryToast.text(MESSAGE_SAVE_FAILE).goAway(700);
    },
    filterRequestList(remittanceList, filter){
      if(
        !filter.status &&
        !filter.searchKeyword
      ){
        return this.remittanceList;
      }
      var result = remittanceList
        .filter(function(remittance){
          if(
            filter.status
          ){
            if(remittance.status == filter.status){
              return remittance;
            }
          }else{
            return remittance;
          }
        })
        .filter(function(remittance){
          if(
            filter.searchKeyword
          ){
            if(
                (
                  remittance.receiver.user &&
                  remittance.receiver.user.title &&
                  remittance.receiver.user.title.includes(filter.searchKeyword)
                ) ||
              remittance.intermediateCompany.name.includes(filter.searchKeyword) ||
              remittance._id.includes(filter.searchKeyword)
            ){
              return remittance;
            }
          }else{
            return remittance;
          }
        })
        ;
      console.log('new result is');
      console.log(result.length);
      return result;
    },

    backToList() {
      this.$router.push({path: '/dashboard'})
    },

    getAllDistributionList() {
      this.isLoading = true;
      RemittanceService
      .getAll_distributionCompany(this.token)
      .then(this.onGetAllDistributionListSuccess)
      .catch(this.onGetAllDistributionListFail);
    },
    onGetAllDistributionListSuccess(response){
      this.remittanceList = response.data.remittanceList
      this.visibleRemittanceList = this.filterRequestList(this.remittanceList, this.filterObject);
      this.isLoading = false;
    },
    onGetAllDistributionListFail(err){
      console.log(err)
      this.isLoading = false;
    },
  },
  created() {
    this.token = localStorage.token;
    if(!this.token){
      this.$router.push({path: '/login'})
    }
    this.getAllDistributionList();
 }
}
