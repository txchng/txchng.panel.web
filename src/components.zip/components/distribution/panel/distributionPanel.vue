<template src="./distributionPanel.html"></template>
<script src="./distributionPanel.ctrl.js"></script>
<style scoped src="./distributionPanel.css"></style>
