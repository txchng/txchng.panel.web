<template src="./distributionFilterModal.html"></template>
<script src="./distributionFilterModal.ctrl.js"></script>
<style scoped src="./distributionFilterModal.css"></style>
