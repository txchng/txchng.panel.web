<template src="./printableDistribution.html"></template>
<script src="./printableDistribution.ctrl.js"></script>
<style scoped src="./printableDistribution.css"></style>
