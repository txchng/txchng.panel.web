<template src="./addDistribution.html"></template>
<script src="./addDistribution.ctrl.js"></script>
<style scoped src="./addDistribution.css"></style>
