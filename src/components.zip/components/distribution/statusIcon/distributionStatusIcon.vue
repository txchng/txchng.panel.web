<template src="./distributionStatusIcon.html"></template>
<script src="./distributionStatusIcon.ctrl.js"></script>
<style scoped src="./distributionStatusIcon.css"></style>
