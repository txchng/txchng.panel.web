<template src="./confirmReverseDistributionModal.html"></template>
<script src="./confirmReverseDistributionModal.ctrl.js"></script>
<style scoped src="./confirmReverseDistributionModal.css"></style>
