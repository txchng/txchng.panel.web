<template src="./distributionSummaryCart.html"></template>
<script src="./distributionSummaryCart.ctrl.js"></script>
<style scoped src="./distributionSummaryCart.css"></style>
