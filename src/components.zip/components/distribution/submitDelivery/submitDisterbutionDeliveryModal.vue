<template src="./submitDisterbutionDeliveryModal.html"></template>
<script src="./submitDisterbutionDeliveryModal.ctrl.js"></script>
<style scoped src="./submitDisterbutionDeliveryModal.css"></style>
