<template src="./totalPendingDistribution.html"></template>
<script src="./totalPendingDistribution.ctrl.js"></script>
<style scoped src="./totalPendingDistribution.css"></style>
