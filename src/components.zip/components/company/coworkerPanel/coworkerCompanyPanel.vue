<template src="./coworkerCompanyPanel.html"></template>
<script src="./coworkerCompanyPanel.ctrl.js"></script>
<style scoped src="./coworkerCompanyPanel.css"></style>
