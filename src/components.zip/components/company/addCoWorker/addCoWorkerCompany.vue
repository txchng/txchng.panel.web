<template src="./addCoWorkerCompany.html"></template>
<script src="./addCoWorkerCompany.ctrl.js"></script>
<style scoped src="./addCoWorkerCompany.css"></style>
