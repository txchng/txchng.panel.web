export default {
    name: "CompnayPanel",
};
