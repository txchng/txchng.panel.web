<template src="./companyPanel.html"></template>
<script src="./companyPanel.ctrl.js"></script>
<style scoped src="./companyPanel.css"></style>
